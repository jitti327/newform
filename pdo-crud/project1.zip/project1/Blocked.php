<?php
  echo "Your Account Is Blocked By Admin Please Contact:- jatin@gmail.com";
?>