<?php
include_once('db/connection.php');

if(isset($_POST['id'])){
$id = $_POST['id'];	
	
$state = $dclass->select('*',`state`, 'AND id='.$id);
			$selOptionsstate = '<option value="">-Select State-</option>';
			
		foreach($state as $key => $val){
			
			$selOptionsstate .= '<option value="'.$val['id'].'">'.$val['name'].'</option>';
													
		}

echo $selOptionsstate;
}

// // add fuel consuption

// if(isset($_POST['fuelProviderName'])){
// $fuelProviderName = $_POST['fuelProviderName'];	
	
// $rowFuelTypeData = $dclass->select('*',$tblFuel, 'AND fuelProviderID='.$fuelProviderID);
// 			$selOptionsType = '<option value="">-Select Fuel Type-</option>';
			
// 		foreach($rowFuelTypeData as $key => $val){
			
// 			$selOptionsType .= '<option value="'.$val['fuelTypeID'].'">'.$val['fuelType'].'</option>';
													
// 		}

// echo $selOptionsType;
// }

// // add fuel grade


// if(isset($_POST['fuelProviderID2'])){
// $fuelProviderID2 = $_POST['fuelProviderID2'];	
	
// $rowFuelProviderData = $dclass->select('*',$tblFuel, 'AND fuelProviderID='.$fuelProviderID);
// 			$selOptionsFuelProvider = '<option value="">-Select Fuel Type-</option>';
			
// 		foreach($rowFuelProviderData as $key => $val){
			
// 			$selOptionsFuelProvider .= '<option value="'.$val['fuelTypeID'].'">'.$val['fuelType'].'</option>';
													
// 		}

// echo $selOptionsFuelProvider;
// }

// if(isset($_POST['fuelType1'])){
// $fuelType1 = $_POST['fuelType1'];	
	
// $rowFuelGradeData = $dclass->select('*',$tblFuelGrade, 'AND fuelType1='.$fuelType1);
// 			$selOptionsGrade = '<option value="">-Select Fuel Grade-</option>';
			
// 		foreach($rowFuelGradeData as $key => $val){
			
// 			$selOptionsGrade .= '<option value="'.$val['fuelgradeID'].'">'.$val['fuelGrade'].'</option>';
													
// 		}

// echo $selOptionsGrade;
// }
// ?>